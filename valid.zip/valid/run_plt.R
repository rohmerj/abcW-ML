library(ggplot2)
library(gridExtra)

rm(list=ls())

tt0 <- theme(
		plot.title = element_text(size=14, face="bold"),
		axis.title.x = element_text(size=14, face="bold"),
		axis.title.y = element_text(size=14, face="bold"),
		axis.text.y= element_text(size=14),
		axis.text.x= element_text(size=12),
		axis.ticks = element_line(size = 1),
		legend.title=element_blank(),
		#legend.position="right",
		legend.position="top",
            #legend.text=element_blank(),
		legend.key.size = unit(0.5, "cm"),
		strip.text = element_text(size = 18)
		)

####################################################
### Validation score for all proportions
####################################################
prop = c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8)
DESIGN = c("LHS")
point = c(3,1,0,-1)# which point: point 3 = Point C1 in the study, point 1 = Point C2, point 0 = Point O1, point -1 = Point O2
point2 = c("Point C1","Point C2","Point O1","Point O2")## for plotting
NIT = 25

MOY = list()
MOY[["Point C1"]]=4.490
MOY[["Point C2"]]=3.90
MOY[["Point O1"]]=5.776
MOY[["Point O2"]]=5.817

cc <- 0

PT <- DESIGN0 <- PROP0 <- NULL
df <- NULL

for (PROP in prop){
	for (POINT in point){

	if (POINT == 3) POINT0 = "Point C1"
	if (POINT == 1) POINT0 = "Point C2"
	if (POINT == 0) POINT0 = "Point O1"
	if (POINT == -1) POINT0 = "Point O2"

	if (DESIGN == "LHS") DESIGN1 = "cLHS"
	if (DESIGN == "ORD") DESIGN1 = "RESAMPL"

	load( 
		file = paste0("./Test_",DESIGN,"Pt",POINT,"_N",PROP,".RData")
		)
	df0 = cbind(
			Q2=Q2[3,],Q2CV=Q2CV[3,],MAE=MRAE[3,],MAECV=MRAECV[3,],
			MS=MS[3,]/MOY[[POINT0]],MSCV=MSCV[3,]/MOY[[POINT0]]
		)
	df = rbind(df,df0)
	PT0=rep(POINT0,25)
	}
	#DESIGN0 = c(DESIGN0,rep(paste0(DESIGN1),25))
	PT=c(PT,c(rep(point2[1],25),rep(point2[2],25),rep(point2[3],25),rep(point2[4],25)))
	PROP0 = c(PROP0,rep(PROP,25*length(point)))

}

df = data.frame(df)
df$PT <- as.factor(PT)
df$PROP <- as.factor(PROP0)

df.plt <- data.frame(
		Q2=c(df$Q2,df$Q2CV),
		MAE=c(df$MAE,df$MAECV),
		S.mean=c(df$MS,df$MSCV),
		#S.sdt.dev=c(df$SS,df$SSCV),
		#CA=c(df$CA,df$CACV),
		PT = rep(as.factor(PT),2),
		PROP = rep(as.factor(PROP0*100),2),
		VALID = c(rep(paste0("Independent ","\n","test set"),nrow(df)),rep("10CV",nrow(df)))
		)
df.plt$VALID <- as.factor(df.plt$VALID)

### Supplementary Materials - FIGURE of Q2
p.q2 <- ggplot(df.plt,aes(PROP,Q2*100,colour=VALID)) + geom_boxplot(size=1.01) + facet_wrap(~PT,ncol=2)+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("p [%]") + ylab("Q² [%]") + tt0# + ylim(6,15)

### Supplementary Materials - FIGURE of MAE
p.mae <- ggplot(df.plt,aes(PROP,MAE,colour=VALID)) + geom_boxplot(size=1.01) + facet_wrap(~PT,ncol=2 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("p [%]") + ylab("MAE [m]") + tt0# + ylim(6,15)

### Supplementary Materials - FIGURE of IQW50%
p.w <- ggplot(df.plt,aes(PROP,S.mean/2*100,colour=VALID)) + geom_boxplot(size=1.01) + facet_wrap(~PT,ncol=2 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("p [%]") + ylab("IQW50 [%]") + tt0# + ylim(6,15)

#########################################################
## For one proportion
#########################################################
prop = c(0.1)
DESIGN = c("LHS")
point = c(3,1,0,-1)
point2 = c("Point C1","Point C2","Point O1","Point O2")
NIT = 25

MOY = list()
MOY[["Point C1"]]=4.490
MOY[["Point C2"]]=3.90
MOY[["Point O1"]]=5.776
MOY[["Point O2"]]=5.817


cc <- 0

PT <- DESIGN0 <- PROP0 <- NULL
df <- NULL

for (PROP in prop){
	for (POINT in point){

	if (POINT == 3) POINT0 = "Point C1"
	if (POINT == 1) POINT0 = "Point C2"
	if (POINT == 0) POINT0 = "Point O1"
	if (POINT == -1) POINT0 = "Point O2"

	if (DESIGN == "LHS") DESIGN1 = "cLHS"
	if (DESIGN == "ORD") DESIGN1 = "RESAMPL"

	load( 
		file = paste0("./Test_",DESIGN,"Pt",POINT,"_N",PROP,".RData")
		)
	df0 = cbind(
			Q2=Q2[3,],Q2CV=Q2CV[3,],MAE=MRAE[3,],MAECV=MRAECV[3,],
			MS=MS[3,]/MOY[[POINT0]],MSCV=MSCV[3,]/MOY[[POINT0]]
		)
	df = rbind(df,df0)
	PT0=rep(POINT0,25)
	}
	#DESIGN0 = c(DESIGN0,rep(paste0(DESIGN1),25))
	PT=c(PT,c(rep(point2[1],25),rep(point2[2],25),rep(point2[3],25),rep(point2[4],25)))
	PROP0 = c(PROP0,rep(PROP,25*length(point)))

}

df = data.frame(df)
df$PT <- as.factor(PT)
df$PROP <- as.factor(PROP0)

df.plt <- data.frame(
		Q2=c(df$Q2,df$Q2CV),
		MAE=c(df$MAE,df$MAECV),
		S.mean=c(df$MS,df$MSCV),
		#S.sdt.dev=c(df$SS,df$SSCV),
		#CA=c(df$CA,df$CACV),
		PT = rep(as.factor(PT),2),
		PROP = rep(as.factor(PROP0*100),2),
		VALID = c(rep(paste0("Independent ","\n","test set"),nrow(df)),rep("10CV",nrow(df)))
		)
df.plt$VALID <- as.factor(df.plt$VALID)

p.q2 <- ggplot(df.plt,aes(PT,Q2*100,colour=VALID)) + geom_boxplot(size=1.01) + #facet_wrap(~PT,ncol=5 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("") + ylab("Q² [%]") + tt0 + ggtitle("(a)")# + ylim(6,15)

p.mae <- ggplot(df.plt,aes(PT,MAE,colour=VALID)) + geom_boxplot(size=1.01) + #facet_wrap(~PT,ncol=5 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("") + ylab("MAE [m]") + tt0+ ggtitle("(b)")# + ylim(6,15)

p.w <- ggplot(df.plt,aes(PT,S.mean/2*100,colour=VALID)) + geom_boxplot(size=1.01) + #facet_wrap(~PT,ncol=5 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("") + ylab("IQW50 [%]") + tt0+ ggtitle("(c)")# + ylim(6,15)

### FIGURE 5
grid.arrange(p.q2,p.mae,p.w,ncol=3)

