library(ggplot2)
library(gridExtra)

rm(list=ls())

tt0 <- theme(
		plot.title = element_text(size=14, face="bold"),
		axis.title.x = element_text(size=14, face="bold"),
		axis.title.y = element_text(size=14, face="bold"),
		axis.text.y= element_text(size=14),
		axis.text.x= element_text(size=12),
		axis.ticks = element_line(size = 1),
		legend.title=element_blank(),
		#legend.position="right",
		legend.position="top",
            #legend.text=element_blank(),
		legend.key.size = unit(0.5, "cm"),
		strip.text = element_text(size = 18)
		)

####################################################
### All proportions
####################################################
prop = c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8)
design = c("LHS")
point = c(3,1)

NIT = 25

cc <- 0

PT <- DESIGN0 <- PROP0 <- NULL
df <- NULL

for (PROP in prop){
for (POINT in point){
for (DESIGN in design){

	if (POINT == 3) POINT0 = 1
	if (POINT == 1) POINT0 = 2

	if (DESIGN == "LHS") DESIGN1 = "cLHS"
	if (DESIGN == "ORD") DESIGN1 = "RESAMPL"
	
	for (IT0 in 1:25){
	DAT = read.table( 
		file = paste0("./","Test_N",PROP,"_IT",IT0,".txt")
		)	
	df = rbind(df,DAT)
	}

	#DESIGN0 = c(DESIGN0,rep(paste0(DESIGN1),25))
	PROP0 = c(PROP0,rep(PROP,25*2))
	PT = c(PT,rep(paste0("Point ",1:2),25))

	}
}

}

df$PT <- as.factor(PT)
df$PROP <- as.factor(PROP0)

df.plt <- data.frame(
		Q2=c(df$Q2,df$Q2CV),
		MAE=c(df$MRAE,df$MRAECV),
		S.mean=c(df$MS,df$MSCV),
		S.sdt.dev=c(df$SS,df$SSCV),
		CA=c(df$CA,df$CACV),
		PT = rep(df$PT,2),
		PROP = rep(df$PROP,2),
		VALID = c(rep(paste0("Independent ","\n","test set"),nrow(df)),rep("10CV",nrow(df)))
		)
df.plt$VALID <- as.factor(df.plt$VALID)

p.q2 <- ggplot(df.plt,aes(PROP,Q2*100,colour=VALID)) + geom_boxplot(size=1.01) + facet_wrap(~PT,ncol=5 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("p") + ylab("Q� [%]") + tt0# + ylim(6,15)

p.mae <- ggplot(df.plt,aes(PROP,MAE,colour=VALID)) + geom_boxplot(size=1.01) + facet_wrap(~PT,ncol=5 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("p") + ylab("MAE [m]") + tt0# + ylim(6,15)

p.w <- ggplot(df.plt,aes(PROP,S.mean,colour=VALID)) + geom_boxplot(size=1.01) + facet_wrap(~PT,ncol=5 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("p") + ylab("Mean IQW [m]") + tt0# + ylim(6,15)

grid.arrange(p.q2,p.mae,p.w,ncol=1)

#########################################################
## For one proportion
#########################################################
prop = 0.3
design = c("LHS")
point = c(3,1)

NIT = 25

cc <- 0

PT <- DESIGN0 <- PROP0 <- NULL
df <- NULL

for (PROP in prop){
for (POINT in point){
for (DESIGN in design){

	if (POINT == 3) POINT0 = 1
	if (POINT == 1) POINT0 = 2

	if (DESIGN == "LHS") DESIGN1 = "cLHS"
	if (DESIGN == "ORD") DESIGN1 = "RESAMPL"
	
	for (IT0 in 1:25){
	DAT = read.table( 
		file = paste0("./","Test_N",PROP,"_IT",IT0,".txt")
		)	
	df = rbind(df,DAT)
	}

	#DESIGN0 = c(DESIGN0,rep(paste0(DESIGN1),25))
	PROP0 = c(PROP0,rep(PROP,25*2))
	PT = c(PT,rep(paste0("Point ",1:2),25))

	}
}

}

df$PT <- as.factor(PT)
df$PROP <- as.factor(PROP0)
#df$DESIGN <- as.factor(DESIGN0)

df.plt <- data.frame(
		Q2=c(df$Q2,df$Q2CV),
		MAE=c(df$MRAE,df$MRAECV),
		S.mean=c(df$MS,df$MSCV),
		S.sdt.dev=c(df$SS,df$SSCV),
		CA=c(df$CA,df$CACV),
		PT = rep(df$PT,2),
		PROP = rep(df$PROP,2),
		#DESIGN = rep(df$DESIGN,2),
		VALID = c(rep(paste0("Independent ","\n","test set"),nrow(df)),rep("10CV",nrow(df)))
		)
df.plt$VALID <- as.factor(df.plt$VALID)

p.q2 <- ggplot(df.plt,aes(PT,Q2*100,colour=VALID)) + geom_boxplot(size=1.01) + #facet_wrap(~PT,ncol=5 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("") + ylab("Q� [%]") + tt0 + ggtitle("(a)")# + ylim(6,15)

p.mae <- ggplot(df.plt,aes(PT,MAE,colour=VALID)) + geom_boxplot(size=1.01) + #facet_wrap(~PT,ncol=5 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("") + ylab("MAE [m]") + tt0+ ggtitle("(b)")# + ylim(6,15)

p.w <- ggplot(df.plt,aes(PT,S.mean/2,colour=VALID)) + geom_boxplot(size=1.01) + #facet_wrap(~PT,ncol=5 )+
	scale_color_manual(values=c("#009E73", "#D55E00"))+
	theme_bw()+ xlab("") + ylab("Mean IQW [m]") + tt0+ ggtitle("(c)")# + ylim(6,15)

grid.arrange(p.q2,p.mae,p.w,ncol=3)


