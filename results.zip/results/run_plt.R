library(ggplot2)
library(gridExtra)
library(dplyr)
library(transport)
library(scoringRules)

rm(list=ls())

tt0 <- theme(
		plot.title = element_text(size=14, face="bold"),
		axis.title.x = element_text(size=14, face="bold"),
		axis.title.y = element_text(size=14, face="bold"),
		axis.text.y= element_text(size=14),
		axis.text.x= element_text(size=14),
		axis.ticks = element_line(size = 1),
		legend.title=element_blank(),
		legend.position="top",
		legend.key.size = unit(1, "cm"),
		strip.text = element_text(size = 18)
		)

#########################################################
## CRPS for all proportions
#########################################################
prop = c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8) # proportion
T = c(100,500) # return period
prob = 1/T # probability related to T
point = c(3,1,0,-1)# which point: point 3 = Point C1 in the study, point 1 = Point C2, point 0 = Point O1, point -1 = Point O2
LIM = 0.1 # ABC threshold
NIT = 25 # number of iterations
DESIGN = "LHS"

NOM = c("RFwE","RFwoE","Subset")
NMOD = length(NOM)

cc <- 0

rp <- MOD <- design <- PT <- CRPS <- NULL

for (PROP in prop){
for (PROB in prob){
for (POINT in point){

	if (POINT == 3) POINT0 = "C1"
	if (POINT == 1) POINT0 = "C2"
	if (POINT == 0) POINT0 = "O1"
	if (POINT == -1) POINT0 = "O2"

	for (j in 1:NIT){
		load(file=paste0("./Test_Pt",POINT,"_N", PROP, "Design", DESIGN, "T", 1/PROB, "IT", j,"abc",LIM, ".RData"))
		cc <- cc + 1

		CRPS.s =crps_sample(median(RL0),RL.s)
		CRPS.m =crps_sample(median(RL0),RL.m)
		CRPS.mr =crps_sample(median(RL0),RL.mr)

		CRPS = c(CRPS,CRPS.mr,CRPS.m,CRPS.s)

		MOD = c(MOD,NOM[1:NMOD])
		design = c(design,rep(PROP*100,NMOD))
		rp = c(rp,rep(paste0("RP=",1/PROB," years"),NMOD))
		PT = c(PT,rep(paste0("Point ",POINT0),NMOD))
		
	}

}
}
}

df0 = data.frame(CRPS)

df0$MOD <- as.factor(MOD)
df0$RP <- as.factor(rp)
df0$PT <- as.factor(PT)
df0$DESIGN <- as.factor(design)

### FIGURE 10
ff =  which(df0$RP == "RP=100 years")
df100 = df0[ff,]
p100 <- ggplot(df100,aes(DESIGN,CRPS,color=MOD)) + geom_boxplot(size=1.025) + facet_wrap(~PT) +
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ xlab("p [%]") + ylab("CRPS") + tt0# + ylim(6,15)

### Supplementary Materials FIGURE for RP=500y
ff =  which(df0$RP == "RP=500 years")
df500 = df0[ff,]
p500 <- ggplot(df500,aes(DESIGN,CRPS,color=MOD)) + geom_boxplot(size=1.025) + facet_wrap(~PT) +
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ xlab("p [%]") + ylab("CRPS") + tt0# + ylim(6,15)

#########################################################
## CRPS for one proportion
#########################################################
ff =  which(df0$RP == "RP=100 years" & df0$DESIGN == 10)
df100 = df0[ff,]
PLT100 <- ggplot(df100,aes(PT,CRPS,color=MOD)) + geom_boxplot(size=1.025) + 
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw() + ylab("CRPS") + xlab("") + tt0+ ggtitle("(a) 100-year RL")

ff =  which(df0$RP == "RP=500 years" & df0$DESIGN == 10)
df500 = df0[ff,]
PLT500 <- ggplot(df500,aes(PT,CRPS,color=MOD)) + geom_boxplot(size=1.025) + 
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw() + ylab("CRPS")+ xlab("") + tt0+ ggtitle("(b) 500-year RL")

### FIGURE 7
grid.arrange(PLT100,PLT500,ncol=2)

#########################################################
## RE for all proportions
#########################################################
prop = c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8) # proportion
T = c(100,500) # return period
prob = 1/T # probability related to T
point = c(3,1,0,-1)# which point: point 3 = Point C1 in the study, point 1 = Point C2, point 0 = Point O1, point -1 = Point O2
LIM = 0.1 # ABC threshold
NIT = 25 # number of iterations
DESIGN = "LHS"

NOM = c("RFwE","RFwoE","Subset")
NMOD = length(NOM)

cc <- 0

rp <- MOD <- design <- PT <- RE <- NULL

for (PROP in prop){
for (PROB in prob){
for (POINT in point){

	if (POINT == 3) POINT0 = "C1"
	if (POINT == 1) POINT0 = "C2"
	if (POINT == 0) POINT0 = "O1"
	if (POINT == -1) POINT0 = "O2"

	for (j in 1:NIT){
		load(file=paste0("./Test_Pt",POINT,"_N", PROP, "Design", DESIGN, "T", 1/PROB, "IT", j,"abc",LIM, ".RData"))
		cc <- cc + 1

		RE.s =(median(RL0)-median(RL.s))/median(RL0)
		RE.m =(median(RL0)-median(RL.m))/median(RL0)
		RE.mr =(median(RL0)-median(RL.mr))/median(RL0)

		RE = c(RE,RE.mr,RE.m,RE.s)

		MOD = c(MOD,NOM[1:NMOD])
		design = c(design,rep(PROP*100,NMOD))
		rp = c(rp,rep(paste0("RP=",1/PROB," years"),NMOD))
		PT = c(PT,rep(paste0("Point ",POINT0),NMOD))
		
	}

}
}
}

df0 = data.frame(RE)

df0$MOD <- as.factor(MOD)
df0$RP <- as.factor(rp)
df0$PT <- as.factor(PT)
df0$DESIGN <- as.factor(design)

### FIGURE 8
ff =  which(df0$RP == "RP=100 years")
df100 = df0[ff,]
p100 <- ggplot(df100,aes(DESIGN,RE*100,color=MOD)) + geom_boxplot(size=1.025) + facet_wrap(~PT) +
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ xlab("p [%]") + ylab("RE [%]") + tt0

### Supplementary Materials FIGURE for RP=500y
ff =  which(df0$RP == "RP=500 years")
df500 = df0[ff,]
p500 <- ggplot(df500,aes(DESIGN,RE*100,color=MOD)) + geom_boxplot(size=1.025) + facet_wrap(~PT) +
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ xlab("p [%]") + ylab("RE [%]") + tt0

#########################################################
## CRPS for one proportion
#########################################################
ff =  which(df0$RP == "RP=100 years" & df0$DESIGN == 10)
df100 = df0[ff,]
PLT100 <- ggplot(df100,aes(PT,RE*100,color=MOD)) + geom_boxplot(size=1.025) + 
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw() + xlab("p [%]") + ylab("RE [%]") + tt0 + ggtitle("(a) 100-year RL")

ff =  which(df0$RP == "RP=500 years" & df0$DESIGN == 10)
df500 = df0[ff,]
PLT500 <- ggplot(df500,aes(PT,RE*100,color=MOD)) + geom_boxplot(size=1.025) + 
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw() + xlab("p [%]") + ylab("RE [%]") + tt0 + ggtitle("(b) 500-year RL")

### FIGURE 6
grid.arrange(PLT100,PLT500,ncol=2)

