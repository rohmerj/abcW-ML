library(ggplot2)
library(gridExtra)
library(dplyr)

rm(list=ls())

tt0 <- theme(
		plot.title = element_text(size=14, face="bold"),
		axis.title.x = element_text(size=14, face="bold"),
		axis.title.y = element_text(size=14, face="bold"),
		axis.text.y= element_text(size=14),
		axis.text.x= element_text(size=14),
		axis.ticks = element_line(size = 1),
		legend.title=element_blank(),
		legend.position="right",
		legend.key.size = unit(0.5, "cm"),
		strip.text = element_text(size = 18)
		)

#########################################################
## RE for all proportions
#########################################################
prop = c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8) # proportion
T = c(100,500) # return period
prob = 1/T # probability related to T
point = c(3,1) # point of interest: 3=Point 1 in the study, 1=Point 2 in the study
LIM = 0.1 # ABC threshold
NIT = 25 # number of iterations
DESIGN = "LHS"

NOM = c("RFwE","RFwoE","Subset")#,"All")
NMOD = length(NOM)

cc <- 0

df0 <- rp <- MOD <- design <- PT <- CA <- NULL

for (PROP in prop){
for (PROB in prob){
for (POINT in point){

	if (POINT == 3) POINT0 = 1
	if (POINT == 1) POINT0 = 2

	for (j in 1:NIT){
		load(file=paste0("./Test_Pt",POINT,"_N", PROP, "Design", DESIGN, "T", 1/PROB, "IT", j,"abc",LIM, ".RData"))
		cc <- cc + 1
		df.rl0 <- df.rl[1:3,c(1,2)]
		df.rl0[1:3,1] <- (df.rl0[1:3,1] - df.rl[4,1])/df.rl[4,1] 
		df0 <- rbind(df0,df.rl0)
		CA0 = NULL
		for (k in 1:3) CA0[k] = ifelse(df.rl[4,1] >= df.rl[k,2] & df.rl[4,1] <= df.rl[k,3], 1, 0)
		CA = c(CA,CA0)
		MOD = c(MOD,NOM[1:NMOD])
		design = c(design,rep(PROP,NMOD))
		rp = c(rp,rep(paste0("RP=",1/PROB," years"),NMOD))
		PT = c(PT,rep(paste0("Point ",POINT0),NMOD))
		
	}

}
}
}

df0$MOD <- as.factor(MOD)
df0$RP <- as.factor(rp)
df0$PT <- as.factor(PT)
df0$DESIGN <- as.factor(design)

ff =  which(df0$RP == "RP=100 years")
df100 = df0[ff,]
p100 <- ggplot(df100,aes(DESIGN,(med)*100,color=MOD)) + geom_boxplot(size=1.025) + facet_wrap(~RP + PT) +
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ xlab("p") + ylab("RE [%]") + tt0# + ylim(6,15)
p100 = p100 + ylim(-50,25)

ff =  which(df0$RP == "RP=500 years")
df500 = df0[ff,]
p500 <- ggplot(df500,aes(DESIGN,(med)*100,color=MOD)) + geom_boxplot(size=1.025) + facet_wrap(~RP + PT) +
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ xlab("p") + ylab("RE [%]") + tt0# + ylim(6,15)
p500 = p500 + ylim(-50,25)

grid.arrange(p100,p500,ncol=1)

#########################################################
##  GPD para. for all proportions
#########################################################
prop = c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8) # proportion
T = c(100,500) # return period
prob = 1/T # probability related to T
point = c(3,1) # point of interest: 3=Point 1 in the study, 1=Point 2 in the study
LIM = 0.1 # ABC threshold
NIT = 25 # number of iterations
DESIGN = "LHS"

NOM = c("RFwE","RFwoE","Subset","All")
NMOD = length(NOM)

cc <- 0

sc <- sh <- rp <- MOD <- design <- PT <- CA <- NULL

for (PROP in prop){
for (PROB in prob){
for (POINT in point){

	if (POINT == 3) POINT0 = 1
	if (POINT == 1) POINT0 = 2

	for (j in 1:NIT){
		load(file=paste0("./Test_Pt",POINT,"_N", PROP, "Design", DESIGN, "T", 1/PROB, "IT", j,"abc",LIM, ".RData"))
		cc <- cc + 1
		sc0 <- df.sc[1:NMOD,c(1)]
		sh0 <- df.sh[1:NMOD,c(1)]
		sc <- c(sc,sc0)
		sh <- c(sh,sh0)
		MOD = c(MOD,NOM[1:NMOD])
		design = c(design,rep(PROP,NMOD))
		rp = c(rp,rep(paste0("RP=",1/PROB," years"),NMOD))
		PT = c(PT,rep(paste0("Point ",POINT0),NMOD))
		
	}

}
}
}

df0 <- data.frame(sh,sc)
df0$MOD <- as.factor(MOD)
df0$RP <- as.factor(rp)
df0$PT <- as.factor(PT)
df0$DESIGN <- as.factor(design)

pscale <- ggplot(df0,aes(DESIGN,(sc),color=MOD)) + geom_boxplot(size=1.025) + facet_wrap(~ PT) +
	scale_color_manual(values=c("#009E73","#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ xlab("p") + ylab("Scale [m]") + tt0# + ylim(6,15)
pscale

pshape <- ggplot(df0,aes(DESIGN,(sh),color=MOD)) + geom_boxplot(size=1.025) + facet_wrap(~PT) +
	scale_color_manual(values=c("#009E73","#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ xlab("p") + ylab("Shape [-]") + tt0# + ylim(6,15)
pshape

grid.arrange(pscale,pshape,ncol=1)

#########################################################
## Coverage for all proportions
#########################################################
prop = c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8) # proportion
T = c(100,500) # return period
prob = 1/T # probability related to T
point = c(3,1) # point of interest: 3=Point 1 in the study, 1=Point 2 in the study
LIM = 0.1 # ABC threshold
NIT = 25 # number of iterations
DESIGN = "LHS"

NOM = c("RFwE","RFwoE","Subset")
NMOD = length(NOM)

cc <- 0

df0 <- rp <- MOD <- design <- PT <- CA <- NULL

for (PROP in prop){
for (PROB in prob){
for (POINT in point){

	if (POINT == 3) POINT0 = 1
	if (POINT == 1) POINT0 = 2

	for (j in 1:NIT){
		load(file=paste0("./Test_Pt",POINT,"_N", PROP, "Design", DESIGN, "T", 1/PROB, "IT", j,"abc",LIM, ".RData"))
		cc <- cc + 1
		CA0 = NULL
		for (k in 1:3) CA0[k] = ifelse(df.rl[4,1] >= df.rl[k,2] & df.rl[4,1] <= df.rl[k,3], 1, 0)
		CA = c(CA,CA0)
		MOD = c(MOD,NOM[1:NMOD])
		design = c(design,rep(PROP,NMOD))
		rp = c(rp,rep(paste0("RP=",1/PROB," years"),NMOD))
		PT = c(PT,rep(paste0("Point ",POINT0),NMOD))
		
	}

}
}
}

df0 <- data.frame(CA)
df0$MOD <- as.factor(MOD)
df0$RP <- as.factor(rp)
df0$PT <- as.factor(PT)
df0$DESIGN <- as.factor(design)

data_summary <- function(data, varname, groupnames){
  require(plyr)
  summary_func <- function(x, col){
	p = mean(x[[col]], na.rm=TRUE)
	v = (1-p)*p
    c(mean = p,
	q1 = ifelse(p - sqrt(v) > 0,p - sqrt(v),0),
	q3 = ifelse(p + sqrt(v) < 1,p + sqrt(v),1)
	)
  }
  data_sum<-ddply(data, groupnames, .fun=summary_func,
                  varname)
  data_sum <- rename(data_sum, c("mean" = varname))
 return(data_sum)
}

ff =  which(df0$RP == "RP=100 years")
df2 = df0[ff,]
df1 <- data_summary(df2, varname="CA", 
                    groupnames=c("MOD", "PT", "DESIGN","RP"))

c100 <- ggplot(df1, aes(x=DESIGN, y=CA*100,fill = MOD)) + 
  geom_bar(stat="identity", color="black", position=position_dodge())+ facet_wrap(~RP + PT) +
  	scale_fill_manual(values=c("#0072B2","#56B4E9","#D55E00"))+
	theme_bw()+ xlab("p") + ylab("C [%]") + tt0

c100

ff =  which(df0$RP == "RP=500 years")
df2 = df0[ff,]
df1 <- data_summary(df2, varname="CA", 
                    groupnames=c("MOD", "PT", "DESIGN","RP"))

c500 <- ggplot(df1, aes(x=DESIGN, y=CA*100,color=MOD,fill = MOD)) + 
  geom_bar(stat="identity", color="black", position=position_dodge())+ facet_wrap(~RP + PT) +
  	scale_fill_manual(values=c("#0072B2","#56B4E9","#D55E00"))+
	theme_bw()+ xlab("p") + ylab("C [%]") + tt0
c500

grid.arrange(c100,c500,ncol=1)

#########################################################
## One proportion - PARA - RL
#########################################################
prop = c(0.3)
T = c(100,500)
prob = 1/T
point = c(3,1)
LIM = 0.1
NIT = 25
DESIGN = "LHS"

NOM = c("RFwE","RFwoE","Subset","All")
NMOD = length(NOM)

cc <- 0

df0 <- rp <- MOD <- design <- PT <- CA <- sc <- sh <- NULL

for (PROP in prop){
for (PROB in prob){
for (POINT in point){

	if (POINT == 3) POINT0 = 1
	if (POINT == 1) POINT0 = 2

	for (j in 1:NIT){
		load(file=paste0("./Test_Pt",POINT,"_N", PROP, "Design", DESIGN, "T", 1/PROB, "IT", j,"abc",LIM, ".RData"))
		cc <- cc + 1
		df.rl0 <- df.rl[1:4,c(1,2)]
		#df.rl0[1:3,1] <- (df.rl0[1:3,1] - df.rl[4,1])#/df.rl[4,1] 
		#df.rl0[1:3,2] <- #(df.rl0[1:3,2] - df.rl[4,2])/df.rl[4,2] 
		df0 <- rbind(df0,df.rl0)
		CA0 = NULL
		for (k in 1:3) CA0[k] = ifelse(df.rl[4,1] >= df.rl[k,2] & df.rl[4,1] <= df.rl[k,3], 1, 0)
		CA = c(CA,CA0)

		sc0 <- df.sc[1:4,c(1)]
		#sc0[1:3] <- (sc0[1:3] - df.sc[4,1])/df.sc[4,1] 
		sh0 <- df.sh[1:4,c(1)]
		#sh0[1:3] <- (sh0[1:3] - df.sh[4,1])/df.sh[4,1] 
		sc <- c(sc,sc0)
		sh <- c(sh,sh0)

		MOD = c(MOD,NOM[1:NMOD])
		design = c(design,rep(PROP,NMOD))
		rp = c(rp,rep(paste0("RP=",1/PROB," years"),NMOD))
		PT = c(PT,rep(paste0("Point ",POINT0),NMOD))
		
	}

}
}
}

df0$MOD <- as.factor(MOD)
df0$RP <- as.factor(rp)
df0$PT <- as.factor(PT)
df0$DESIGN <- as.factor(design)
df0$SCALE <- sc
df0$SHAPE <- sh

labels = c("(a)","(b)","(c)","(d)")

ff <- which(df0$RP == levels(df0$RP)[1])
p100 <- ggplot(df0[ff,],aes(PT,(med),color=MOD)) + geom_boxplot(size=1.025) + 
	scale_color_manual(values=c("#009E73","#0072B2","#56B4E9","#D55E00"))+#,
	theme_bw() + ylab("100-year RL [m]") + xlab("") + tt0# + ylim(6,15)+ xlab("Proportion of training data")
p100 <- p100 + ggtitle(labels[3])

ff <- which(df0$RP == levels(df0$RP)[2])
p500 <- ggplot(df0[ff,],aes(PT,(med),color=MOD)) + geom_boxplot(size=1.025) + 
	scale_color_manual(values=c("#009E73","#0072B2","#56B4E9","#D55E00"))+#,
	theme_bw() + ylab("500-year RL [m]") + xlab("") +  tt0# + ylim(6,15)+ xlab("Proportion of training data")
p500 <- p500 + ggtitle(labels[4])


psc <- ggplot(df0[ff,],aes(PT,(SCALE),color=MOD)) + geom_boxplot(size=1.025) +
	scale_color_manual(values=c("#009E73","#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ ylab("Scale para. [m]") + xlab("") + tt0# + ylim(6,15)+ xlab("Proportion of training data") 
psc <- psc + ggtitle(labels[1])

psh <- ggplot(df0[ff,],aes(PT,(SHAPE),color=MOD)) + geom_boxplot(size=1.025) + 
	scale_color_manual(values=c("#009E73","#0072B2","#56B4E9","#D55E00"))+#"#009E73",
	theme_bw()+ ylab("Shape para. [-]") + xlab("") +  tt0# + ylim(6,15)+ xlab("Proportion of training data") 
psh <- psh + ggtitle(labels[2])

grid.arrange(psc,psh,p100,p500,ncol=2)

#########################################################
## One proportion - Coverage
#########################################################
prop = c(0.3)
T = c(100,500)
prob = 1/T
point = c(3,1)
LIM = 0.1
NIT = 25
DESIGN = "LHS"

NOM = c("RFwE","RFwoE","Subset")
NMOD = length(NOM)

cc <- 0

df0 <- rp <- MOD <- design <- PT <- CA <- sc <- sh <- NULL

for (PROP in prop){
for (PROB in prob){
for (POINT in point){

	if (POINT == 3) POINT0 = 1
	if (POINT == 1) POINT0 = 2

	for (j in 1:NIT){
		load(file=paste0("./Test_Pt",POINT,"_N", PROP, "Design", DESIGN, "T", 1/PROB, "IT", j,"abc",LIM, ".RData"))
		cc <- cc + 1

		CA0 = NULL
		for (k in 1:3) CA0[k] = ifelse(df.rl[4,1] >= df.rl[k,2] & df.rl[4,1] <= df.rl[k,3], 1, 0)
		CA = c(CA,CA0)

		MOD = c(MOD,NOM[1:NMOD])
		design = c(design,rep(PROP,NMOD))
		rp = c(rp,rep(paste0("RP=",1/PROB," years"),NMOD))
		PT = c(PT,rep(paste0("Point ",POINT0),NMOD))
		
	}

}
}
}

df0 <- data.frame(CA)
df0$MOD <- as.factor(MOD)
df0$RP <- as.factor(rp)
df0$PT <- as.factor(PT)
df0$DESIGN <- as.factor(design)


library(dplyr)
data_summary <- function(data, varname, groupnames){
  require(plyr)
  summary_func <- function(x, col){
	p = mean(x[[col]], na.rm=TRUE)
	v = (1-p)*p
    c(mean = p,
	q1 = ifelse(p - sqrt(v) > 0,p - sqrt(v),0),
	q3 = ifelse(p + sqrt(v) < 1,p + sqrt(v),1)
	)
  }
  data_sum<-ddply(data, groupnames, .fun=summary_func,
                  varname)
  data_sum <- rename(data_sum, c("mean" = varname))
 return(data_sum)
}

df1 <- data_summary(df0, varname="CA", 
                    groupnames=c("MOD", "PT","RP"))

cov<- ggplot(df1, aes(x=PT, y=CA*100,fill = MOD)) + 
  geom_bar(stat="identity", color="black", position=position_dodge())+ 
	facet_wrap(~RP) +
	scale_color_manual(values=c("#0072B2","#56B4E9","#D55E00"))+
	scale_fill_manual(values=c("#0072B2","#56B4E9","#D55E00"))+
	theme_bw()+ xlab("") + ylab("C [%]") + tt0
cov

